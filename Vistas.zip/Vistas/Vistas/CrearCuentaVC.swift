//
//  CrearCuentaVC.swift
//  Vistas
//
//  Created by Macbook on 11/29/18.
//  Copyright © 2018 Macbook. All rights reserved.
//

import UIKit
import Firebase


class CrearCuentaVC: UIViewController {

    
    @IBOutlet weak var nombre: UITextField!
    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var password: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func backToLogin(_ sender: UIButton){
        navigationController?.popViewController(animated: true)
    }
    
    
    @IBAction func createAccount(_ sender: UIButton) {
        guard let correo = email.text,
            let pass = password.text,
            let username = nombre.text else { return }
        print(correo)
        Auth.auth().createUser(withEmail: correo, password: pass) { (data, error) in
            if let error = error{
                debugPrint(error.localizedDescription)
            }
            
            let user = data?.user
            let changeRequest = user?.createProfileChangeRequest()
            changeRequest?.displayName = username
            changeRequest?.commitChanges(completion: { (error) in
                if let error = error{
                    debugPrint(error.localizedDescription)
                }
            })
            
            guard let userId = user?.uid else { return }
            
            Firestore.firestore().collection("users").document(userId).setData([
                "username" : username,
                "date_created": FieldValue.serverTimestamp()
                ], completion: { (error) in
                    if let error = error {
                        debugPrint(error)
                    }else{
                        self.navigationController?.popViewController(animated: true)
                    }
            })
        }
        
    }
    
}
